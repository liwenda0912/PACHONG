import requests
import json
from bs4 import BeautifulSoup
import re

url = 'https://91mjw.com/page/6'
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36'
}
response = requests.get(url=url, headers=headers)
d = response.text

data = BeautifulSoup(d, 'lam')

move = data.find('div', class_="content")
print(move.text)
with open('../d.txt', 'w', encoding='utf-8') as f:
    f.write(d)

for i in move.find_all('a'):
    print(i.text)
    with open('../move.txt', 'a', encoding='utf-8')as f:
        f.write(i.text)
        f.write('\n\n')
