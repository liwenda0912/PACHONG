import requests
from bs4 import BeautifulSoup
import pandas as pd
import xlwt
import re

head = {  # 这里根据自己的电脑构建
}
url = 'https://gz.lianjia.com/ershoufang/pg6/'
data = requests.get(url, headers=head)  # 获取URL
data.encoding = 'utf-8'  # 设置URL的字符编码
html = data.text  # 获取URL的文本模式
print(html)
pattern = re.compile(
    r'<div class="title"><a class=.*?>(.*?)</a>.*?<div class="houseInfo".*?/span>(.*?)</div>.*?<div class="priceInfo">.*?span>(.*?)</span>万</div><div class="unitPrice".*?<span>(.*?)</span></div>',
    re.I | re.M)  # 搜索需要查找的文字并设置忽略大小写和多行模式
result = re.findall(pattern, html)  # 在HTML文本里面遍历匹配，可以获取字符串中所有匹配的字符串，返回一个列表
print(result)
for item in result:
    house_name = item[0]
    house = item[1]
    price = item[2] + '万'
    unitPrice = item[3]

    with open('../二手房信息.txt', 'a', encoding='utf-8') as f:
        f.write((house_name + ':' + house + '。' + '总价为：' + price + '。' + unitPrice))

        f.write('\n\n')

        wb = xlwt.Workbook(encoding='utf-8')
        ws = wb.add_sheet('sheet1')
        # for j in range (p):
        #  print(j)
        #  ws.write(0,j,house_name)
        #  wb.save('二手房.xls')
        #  p = p + 1
        # print(p)
