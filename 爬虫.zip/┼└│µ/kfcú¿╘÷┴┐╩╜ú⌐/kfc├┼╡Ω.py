import requests

import goto
import label
from goto import with_goto
import csv


@with_goto
def kfc():
    label.begin
    import json
    a = input("是否要查询（yes/no）：")
    if a == 'yes':
        url = 'http://www.kfc（增量式）.com.cn/kfccda/ashx/GetStoreList.ashx?op=keyword'
        kw = input("请输入要查询的门店：")
        params = {
            'cname': '',
            'pid': '',
            'keyword': kw,
            'pageIndex': '1',
            'pageSize': '10'
        }
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36'
        }

        response = requests.post(url=url, params=params, headers=headers)
        data = response.json()
        D = data.get('Table1')
        fp = open('kfc（增量式）.json', 'w', encoding='utf-8')
        json.dump(D, fp=fp, ensure_ascii=False)
        fp.close()

        import json
        with open('kfc（增量式）.json', 'r', encoding='utf-8')as f:
            Data = json.load(f)
        da = open('kfc（增量式）.csv', 'a', encoding='utf-8')
        import csv
        data = csv.writer(da)
        data.writerow(Data[0].keys())
        for i in Data:
            data.writerow(i.values())
        f.close()
        da.close()
        goto.begin
    else:
        print("bye")

        import pandas as pd
        ha = pd.read_csv('kfc（增量式）.csv', encoding='utf-8')
        ha.to_excel('kfc（增量式）.xlsx', encoding='utf-8')


c = kfc()
