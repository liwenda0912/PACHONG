import json
import pandas as pd
with open('kfc（增量式）.json', 'r', encoding='utf-8')as f:
    Data = json.load(f)
da = open('kfc（增量式）.csv', 'w', encoding='utf-8')
import csv

data = csv.writer(da)
data.writerow(Data[0].keys())
for i in Data:
    data.writerow(i.values())

f.close()
da.close()



ha = pd.read_csv('kfc（增量式）.csv', encoding='utf-8')
ha.to_excel('liwenda.xlsx', encoding='utf-8')
