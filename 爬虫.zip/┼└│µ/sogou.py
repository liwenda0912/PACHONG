import requests

url = 'https://www.sogou.com/'
response = requests.get(url=url)  # get方法会返回一个响应对象
a = response.text  # 获取响应数据，text返回的是字符串形式的响应数据
print(a)
with open('a.html', 'w', encoding='utf-8') as fp:
    fp.write(a)
    print('数据爬取结束！')
