import requests
from lxml import html

etree = html.etree

url = 'http://v.hao123.baidu.com/dianying'
headers = {
    'User-Agent': "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"
}
response = requests.get(url=url, headers=headers).text
et = etree.HTML(response)

data = et.xpath('//div/a/@href')
print(data)
