# from lxml import etree
# 或者
import requests
from lxml import html

etree = html.etree

url = "https://new.qq.com/omn/20220211/20220211A02KUI00.html"
headers = {
    'User-Agent': "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"
}

pagesource = requests.get(url=url, headers=headers).text
# 加载数据，返回element对象3
et = etree.HTML(pagesource)
# xpath语法
# 固定在HTML里面提取
# result = et.xpath("/html")  # /html表示根节点
# result = et.xpath("/html/body/div/div/h1/text()")  # 表达式中间的/表示一层html节点,text()表示提取标签中的文本信息
# result = et.xpath("/html/body/div/@id")  # 提取超文本的网址和文本(属性用@加属性标签，*代表在某个实体里面任意的，通配符)
# 任意位置
# result = et.xpath("//div/@id") #  //表示任意的位置
# 指定位置提取信息
# result = et.xpath("//div[@class='LEFT']/h1/text()")  # [@xx=xxx]属性的限定
# print(result)
# 带循环的
result = et.xpath("//div/*/p")
for i in result:
    a = i.xpath("./text()")[0]  # ./代表当前这个元素,[0]代表列表里的元素
    p = i.xpath("./@class")[0]
    print(p, a)
