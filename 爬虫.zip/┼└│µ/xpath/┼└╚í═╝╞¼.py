from  lxml import html
import requests
import os
if not os.path.exists('./p'):
    os.makedirs('./p')
etree = html.etree # 设置etree为html包里的etree
url = "https://www.jj20.com/tx/nusheng/336972.html"
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36'
}
picturesource = requests.get(url=url, headers=headers)
picturesource.encoding= 'gb2312'
picturesource= picturesource.text
et = etree.HTML(picturesource)# 把爬取到的html转变为element

result = et.xpath('//ul//img/@src')
for i in result:
 url1 = "https:"+i
 picture = requests.get(url=url1, headers=headers).content
 name = i.split('/')[-1]
 path = './p/'+name
 with open(path,'wb')as f :
     f.write(picture)
     print(path + "下载成功！")



