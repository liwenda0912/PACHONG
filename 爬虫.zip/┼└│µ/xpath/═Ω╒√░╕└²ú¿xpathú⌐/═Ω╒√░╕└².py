
import requests
from lxml import html
import os
from concurrent.futures import ThreadPoolExecutor

domain = "https://desk.zol.com.cn/"


# 获取页面里列表的所有的url
def img_url(url, headers):
    response = requests.get(url=url, headers=headers)
    response.encoding = 'gbk'
    etree = html.etree
    et = etree.HTML(response.text)
    result = et.xpath("//ul[@class='pic-list2  clearfix']/li/a/@href")  # 获取页面里的所有url
    img_src_url = []
    for i in result:
        print(f"开始获取页面里的url{i}")
        img_src_url.append(domain + i)  # 添加URL进入列表img_src_url
        print(f"完成页面里的url的获取{i}")
    img_src_url.remove(img_src_url[0]) # 去除不是url的字符

    return img_src_url


# 获取url里的每张图片的url
def img_src_url(new_href):
    src_url = []
    list_name = []
    print(f"开始获取每一张图片的url{i}")
    response = requests.get(url=new_href)
    etree = html.etree
    et = etree.HTML(response.text)
    obj = et.xpath("//ul[@id='showImg']/li/a/img/@srcs") + et.xpath("//ul[@id='showImg']/li/a/img/@src")  # 获取图片的img的url
    name = et.xpath("//div[@class='wrapper photo-tit clearfix']/h3/a/text()")  # 获取列表名称
    src_url.append(obj)  # 添加img的url进入列表obj
    list_name.append(name)  # 添加列表名称进入列表list_name
    return src_url, list_name


# 下载图片
def download(src_href):
    for url in src_href:
        listname = src_href[1][0][0]
        url = src_href[0][0]
        if not os.path.exists(listname):  # 创建以列表名称的文档（如果不存在就创建）
            os.mkdir(listname)
        for url1 in url:
            data = requests.get(url=url1).content #  获取图片的二进制
            name = url1.split('/')[-1]  # 获取图片得名称
            print(f"开始下载图片{name}")
            path = './'+listname+'/'+name # 图片保存路径
            with open(path, 'wb')as f:
                f.write(data)
                print(f"完成{name}的下载")


def main():
    url = "https://desk.zol.com.cn/pc/"
    headers = {
        'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36"
    }
    new_href = img_url(url, headers)  # 赋值给函数img_url
    for i in new_href:
        src_href = img_src_url(i)  # 获取每一张图片的url
        with ThreadPoolExecutor(20) as t:  # 线程池
            t.submit(download, src_href)  # 设置多线程


if __name__ == '__main__':
    main()
