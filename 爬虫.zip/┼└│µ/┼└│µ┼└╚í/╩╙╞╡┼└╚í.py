import requests
import you_get
from lxml import html
import sys
from you_get import common


url = "https://haokan.baidu.com/videoui/api/videorec?title=%E4%B8%AD%E5%9B%BD%E7%8E%B0%E5%BD%B9%E8%8A%B1%E6%BB%91%E5%A5%B3%E7%A5%9E%E9%99%88%E8%99%B9%E4%BC%8A%EF%BC%8C%E7%BF%A9%E8%8B%A5%E6%83%8A%E9%B8%BF%EF%BC%8C%E5%A9%89%E8%8B%A5%E6%B8%B8%E9%BE%99%EF%BC%8C%E6%9C%80%E7%BE%8E%E5%86%B0%E7%BE%8E%E4%BA%BA&vid=5668587328247352739&act=pcRec&pd=pc"
headers = {
    'User-Agent': "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"
}
response = requests.get(url=url, headers=headers)
data = response.json()
videosdata = (data['data']['response']['videos'])
for i in videosdata:
    n = i['title']
    url1 = i['play_url']
    #   sys.argv = ['you_get', '-o', './p', url1]#  'you_get'代表下载方式, '-o'代表you_get里面的下载参数, './p'代表下载地址, url1代表视频网址
    #   you_get.main()# 下载视频
    # 2.common方法下载
    # common.any_download(url1, stream_id='mp4', output_dir=r'./p')# stream_id=‘mp4‘代表视频是高清的，url1代表的是视频的网址，output——dri=**代表的是下载到的地方

    # 3 用content
    picture = requests.get(url=url1, headers=headers).content
    path = './p/'+i['id']+'.mp4'
    with open(path,'wb')as f:
       f.write(picture)
       print(path + "下载成功！")
