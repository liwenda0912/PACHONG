import requests

# ua伪装；让爬虫对应请求载体身份标识伪装成为一款浏览器

url = 'https://www.sogou.com/web'
# User-Agent：表示请求载体的身份标识
# ua伪装：将对应的user-agent封装到param里（字典）(反反爬机制）
headers = {
    'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36"
}
# 处理url携带的参数：封装到字典里
ke = input('enter a word:')
param = {
    'query': ke
}
# 对指定的url发起的请求对应的url参数的，并且请求过程中处理了参数

response = requests.get(url=url, params=param, headers=headers)
s = response.text
print(s)
filename = ke + '.html'
with open(filename, 'w', encoding='utf-8')as fp:
    fp.write(s)
    print("数据获取成功！")
