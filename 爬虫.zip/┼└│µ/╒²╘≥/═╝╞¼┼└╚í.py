import requests
import re
import os
if not os.path.exists('./name'):
    os.makedirs('./name')

url = "https://www.jj20.com/bz/zrfg/ssrh/276857.html"
headers = {
    'User-Agent': "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"
}
data = requests.get(url=url, headers=headers).text
data1 = '<img src="(.*?)" .*?'
response = re.findall(data1, data, re.M | re.S)
for i in response:
    p = 'http:'+i
    name = i.split('/')[-1]
    print(i)
    path = './name/' + name
    with open(path, 'wb')as f:
        for i1 in response:
            print(i1)
            url1 = 'http:' + i1
            p = requests.get(url=url1, headers=headers).content
            f.write(p)
            print(path+"下载成功！")

