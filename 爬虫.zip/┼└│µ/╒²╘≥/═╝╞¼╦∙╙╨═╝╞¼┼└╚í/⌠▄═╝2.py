import requests
import re
import os

if not os.path.exists('./picture'):  # 生成一个文件夹，如果文件夹不存在就生成一个新的文件夹
    os.mkdir('./picture')  # 生成名为picture的文件夹
url = "https://www.qiushibaike.com/imgrank/page/%d/"
headers = {
    'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36"
}
num = int(input("输入要爬取图片的页数:"))
url = format(url % num)  # 将page的数字添加到url上面去形成一个新的url
response = requests.get(url=url, headers=headers).text
ex = '<div class="thumb">.*?<img src="(.*?)" alt.*?</div>'  # 对页面的所有糗图进行解析与爬取
data = re.findall(ex, response, re.S | re.M)  # 正则

for i in data:
    url = 'https:' + i  #  url的正确的URL路径，而里的是没有HTTPS://前缀的
    headers = {
        'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36"
    }
    name = i.split('/')[-1]  # 在i里获取图片的名称
    path = './picture/' + name  # 图片存储路径
    response = requests.get(url=url, headers=headers).content  # content返回二进制形式的图片形式，#text（字符串），json（）（对象# ）
    with open(path, 'wb')as f:  # 进行一张张图片存储
        f.write(response)
        print(path + '下载成功')
