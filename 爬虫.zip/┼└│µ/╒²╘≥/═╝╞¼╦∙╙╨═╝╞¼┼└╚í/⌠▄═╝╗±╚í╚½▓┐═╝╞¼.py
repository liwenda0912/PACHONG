import requests
import re
import os

if not os.path.exists('./qiutu'):
    os.mkdir('./qiutu')
url = "https://www.qiushibaike.com/imgrank/"
headers = {
    'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36"
}

response = requests.get(url=url, headers=headers).text
ex = '<div class="thumb">.*?<img src="(.*?)" alt.*?</div>'  # 对页面的所有糗图进行解析与爬取
data = re.findall(ex, response, re.S | re.M)  # 正则】

for i in data:
    url = 'https:' + i
    headers = {
        'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36"
    }
    name = i.split('/')[-1]
    path = './qiutu/' + name
    response = requests.get(url=url, headers=headers).content  # content返回二进制形式的图片形式，#text（字符串），json（）（对象# ）
    print(response)
    with open(path, 'wb')as f:
        f.write(response)
        print(path + '下载成功')
