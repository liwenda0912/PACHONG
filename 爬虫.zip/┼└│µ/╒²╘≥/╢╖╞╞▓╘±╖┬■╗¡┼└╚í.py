import requests
import re

url = "https://baijiahao.baidu.com/s?id=1724424551475251148&wfr=spider&for=pc"
headers = {
    'User-Agent': "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"}
data = requests.get(url=url, headers=headers).text
data1 = '<a href="(.*?)".*?'  # 正则获取网站
data2 = '<div class=".*?">(.*?)</div>'  # 正则获取div里面的东西
new = re.findall(data1, data, re.M | re.S)

print(new)
for i in new:
   with open('../xingwen.txt', 'a', encoding='utf-8')as f:
    f.write(i)
