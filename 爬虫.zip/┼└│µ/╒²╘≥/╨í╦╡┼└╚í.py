import requests
import re

url = "https://www.shengxu5w.com/4_4676/12244297.html"
headers = {
    'User-Agent': "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"
}
data = requests.get(url=url, headers=headers)
data.encoding = 'gb2312'
data1 = data.text
p = '<a title=.*? href=.*?>(.*?)</a>'
p1 = '<a href=.*?>(.*?)</a>'
p2 = '&nbsp;&nbsp;&nbsp;&nbsp;(.*?)<br />'
result = re.findall(p, data1, re.M | re.I)
result1 = re.findall(p1, data1, re.M | re.I)
result2 = re.findall(p2,data1, re.M | re.I)
print(result2)
