import requests
import json
import csv
import json
import pandas as pd
url = 'https://movie.douban.com/j/chart/top_list'
param = {
    'type': '24',
    'interval_id': '100:90',
    'action': '',
    'start': '40',
    'limit': '20',
}
headers = {
    'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36"
}
response = requests.get(url=url, params=param, headers=headers)
data = response.json()
print(data)
fp = open('电影.json', 'w', encoding='utf-8')
json.dump(data, fp=fp, ensure_ascii=False)
print("over!!!")

fp.close()

# json转换为csv文件
with open('电影.json', 'r', encoding='utf-8')as f:  # 打开json文件，获取json数据
    rows = json.load(f)
print(rows)
f = open('data1.csv', 'w', encoding='utf-8')  # 创建文件
csv_write = csv.writer(f)  # 创建csv文件对象
csv_write.writerow(rows[0].keys())  # 写入数据，取列表的第一行字典，用字典的key只作为头行数据
# #循环里面的字典将values值作为数据写进去
for row in rows:
    csv_write.writerow(row.values())
f.close()  # 关闭打开的文件

# csv转换为excel文件


csv = pd.read_csv('data.csv', encoding='utf-8')  # 读取csv文件
csv.to_excel('1.xlsx', encoding='utf-8')  # csv转换成为excel文件
