import requests
from lxml import html
import re
import json
from concurrent.futures import ThreadPoolExecutor

domain = "https://desk.zol.com.cn/"


# 获取页面里列表的所有的url
def img_url(url, headers):

    response = requests.get(url=url, headers=headers)
    response.encoding = 'gbk'
    etree = html.etree
    et = etree.HTML(response.text)
    result = et.xpath("//ul[@class='pic-list2  clearfix']/li/a/@href")  # 获取页面里的url
    img_src_url = []
    for i in result:
        print(f"开始获取页面里的url{i}")
        img_src_url.append(domain + i)  # 添加img的url进入列表obj
        print(f"完成页面里的url的获取{i}")
    img_src_url.remove(img_src_url[0])  # 添加列表名称进入列表list_name

    return img_src_url


# 获取url里的每张图片的url
def img_src_url(new_href):

    src_url = []
    for i in new_href:
        print(f"开始获取每一张图片的url{i}")
        response = requests.get(url=i)
        data = 'var deskPicArr.*?=(.*?);'
        obj = re.findall(data, response.text, re.M | re.S)  # 正则获取图片的url
        result = json.loads(obj[0])  # 字符转换为json格式
        for item in result['list']:
            oriSize = item['oriSize']  # 获取图片像素
            imgsrc = item['imgsrc']   # 获取图片url
            imgsrc = imgsrc.replace("##SIZE##", oriSize)  # 替换图像像素
            src_url.append(imgsrc)
            print(f"完成每一张图片的url的获取{imgsrc}")
    return src_url


# 下载图片
def download(src_href):
    for url in src_href:

        data = requests.get(url=url).content  # 获取图像的二进制格式
        name = url.split('/')[-1]  # 获取图像的名称
        print(f"开始下载图片{name}")
        path = './p/' + name  # 图像保存路径
        with open(path, 'wb')as f:
            f.write(data)
            print(f"完成{name}的下载")


def main():
    url = "https://desk.zol.com.cn/pc/"
    headers = {
        'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36"
    }
    new_href = img_url(url, headers)  # 赋值给函数img_url

    src_href = img_src_url(new_href)  # 获取每一张图片的url

    with ThreadPoolExecutor(20) as t: # 线程池
        t.submit(download, src_href)


if __name__ == '__main__':
    main()
