from concurrent.futures import ThreadPoolExecutor


def func(name):
    for i in range(100):
        print(name, i)


if __name__ == '__main__':
    with ThreadPoolExecutor(20)as t:
        t.submit(func, "liwenda")
        t.submit(func, "litingting")
