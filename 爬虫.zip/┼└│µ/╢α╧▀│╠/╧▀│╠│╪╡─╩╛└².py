from concurrent.futures import ThreadPoolExecutor
import requests
import json
import os


def download(url1,n):

    print(f"准备下载{url1}")
    headers1 = {
        'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36"
    }
    pathpic = './p/' + str(n) + ".jpg"
    p = requests.get(url=url1, headers=headers1).content
    with open(pathpic, 'wb')as f:
        f.write(p)
    print(n,"下载完毕！")


def main():
    if not os.path.exists('./p'):
        os.mkdir('./p')
    url = 'https://image.baidu.com/simple/simplesearch?word=%E5%9B%BE%E7%89%87&pn=0&rn=30&cs=1430875916,266596446&os=2808269621,4031452111&is=0,0&simid=1430875916,266596446&appname=pc&tn=baiduimagedetail&di=7060663421280190465&bdtype=0&objurl=https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fimg.jj20.com%2Fup%2Fallimg%2Ftp09%2F21031FKU44S6-0-lp.jpg&refer=http%3A%2F%2Fimg.jj20.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1649999141&t=cf88181caae81bf075c4766b1b246078&pn=0&rn=30'
    headers = {
        'User-Agent': "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"
    }
    n = 0
    data = requests.get(url=url, headers=headers).text
    data = json.loads(data)
    with ThreadPoolExecutor(100)as t:
        for i in data['goodsData']['items']:
            n = n + 1
            url1 = i.get('thumbnailUrl') + '.jpg'
            t.submit(download,url1,n)
    print("download over!")


if __name__ == '__main__':
    main()
