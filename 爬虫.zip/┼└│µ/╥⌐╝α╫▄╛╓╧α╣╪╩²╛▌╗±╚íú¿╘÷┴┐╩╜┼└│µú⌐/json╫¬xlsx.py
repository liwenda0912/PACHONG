import json
import csv
import pandas as pd

with open('详细数据.json', 'r', encoding='utf-8') as f:
    D = json.load(f)
print(D)
date = open('详细数据.csv', 'w', encoding='utf-8')
message = csv.writer(date)
message.writerow(D[0].keys())
for i in D:
    message.writerow(i.values())
date.close()
f.close()

da = pd.read_csv('详细数据.csv', encoding='utf-8')
da.to_excel('message.xls', encoding='utf-8')
