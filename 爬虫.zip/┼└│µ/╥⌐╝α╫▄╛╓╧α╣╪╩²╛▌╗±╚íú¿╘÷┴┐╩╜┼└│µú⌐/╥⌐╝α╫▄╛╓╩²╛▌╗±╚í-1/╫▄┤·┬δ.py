import requests
import json
import csv
import pandas as pd
all_id_data = []
id_dict = []
for page1 in range(1, 6):
    url = 'http://scxk.nmpa.gov.cn:81/xk/itownet/portalAction.do'
    params = {
        'method': 'getXkzsList',
        'page': page1
    }
    headers = {
        'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36"
    }

    response = requests.post(url=url, params=params, headers=headers)
    data = response.json()
    for i in data['list']:
        id_dict.append(i['ID'])
print(len(id_dict))
for id1 in id_dict:
    url = 'http://scxk.nmpa.gov.cn:81/xk/itownet/portalAction.do?method=getXkzsById'
    params = {
        'method': 'getXkzsById',
        'id': id1
    }
    headers = {
        'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36"
    }
    response = requests.post(url=url, params=params, headers=headers)
    d = response.json()
    all_id_data.append(d)

f = open('1.json', 'a', encoding='utf-8')
json.dump(all_id_data, fp=f, ensure_ascii=False)

with open('1.json', 'r', encoding='utf-8') as f:
    D = json.load(f)
date = open('1.csv', 'a', encoding='utf-8')
message = csv.writer(date)
message.writerow(D[0].keys())
for i in D:
    message.writerow(i.values())
date.close()
f.close()
apple = str(page1) + '.xlsx'


da = pd.read_csv('1.csv', encoding='utf-8')
da.to_excel('1.xlsx', encoding='utf-8')
print('over!!')
