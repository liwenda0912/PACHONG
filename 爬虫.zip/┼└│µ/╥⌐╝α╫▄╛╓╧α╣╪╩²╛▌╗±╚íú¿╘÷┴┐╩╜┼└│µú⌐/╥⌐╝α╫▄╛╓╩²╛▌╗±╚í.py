import requests
import json

url = 'http://scxk.nmpa.gov.cn:81/xk/itownet/portalAction.do'

params = {
    'method': 'getXkzsList',
    'page': '1'
}
headers = {
    'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36"
}
response = requests.post(url=url, params=params, headers=headers)
data = response.json()
data = data.get('list')
for i in range(len(data)):
    a = data[i].get('ID')
    with open('date.txt', 'a', encoding='utf-8')as f:
        f.write(a)
        f.write('\n')
