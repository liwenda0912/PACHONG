import requests
import json
import csv
date=[]
data=open('date.txt','r',encoding='utf-8')
for i in data:
  a=i
  if a!=' ':
      import requests

      url = 'http://scxk.nmpa.gov.cn:81/xk/itownet/portalAction.do?method=getXkzsById'
      params = {
          'method': 'getXkzsById',
          'id': a

      }
      headers = {
          'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36"
      }
      response = requests.post(url=url, params=params, headers=headers)
      d = response.json()
      date.append(d)
      f=open('详细数据.json','w',encoding='utf-8')
      json.dump(date,fp=f,ensure_ascii=False)

