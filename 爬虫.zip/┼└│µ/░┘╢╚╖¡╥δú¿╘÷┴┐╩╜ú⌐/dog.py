import csv
import json
with open('dog.json','r',encoding='utf-8') as f:
      rows=json.load(f)
rows=rows['data']
dog=open('1.csv','w',encoding='utf-8')
pupy=csv.writer(dog)
pupy.writerow(rows[1].keys())
for row in rows:
      pupy.writerow(row.values())
dog.close()

import pandas as pd

data=pd.read_csv('1.csv',encoding='utf-8')
data.to_excel('1.xlsx',encoding='utf-8',)