import requests
import json
#用requests去获取post请求
url='https://fanyi.baidu.com/sug'
headers={
    'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36'
}
word=input("输入要翻译的英文：")
#post请求参数处理（同get请求一致）
param={
    'kw':word
}
response=requests.post(url=url,params=param,headers=headers)
#获取响应对象：json方法返回是obj（如果是携带参数是json类型的，才可以使用json（））
data=response.json()
filename=word+'.json'
fp=open(filename,'w',encoding='utf-8')
json.dump(data,fp=fp,ensure_ascii=False)
print(data)
print("over!!!")

